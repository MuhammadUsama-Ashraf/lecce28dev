module.exports=[97947,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28organic%29_terms-conditions_page_actions_1cz0sq-.js.map