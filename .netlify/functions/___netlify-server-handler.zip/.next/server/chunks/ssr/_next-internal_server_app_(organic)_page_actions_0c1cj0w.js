module.exports=[76395,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28organic%29_page_actions_0c1cj0w.js.map