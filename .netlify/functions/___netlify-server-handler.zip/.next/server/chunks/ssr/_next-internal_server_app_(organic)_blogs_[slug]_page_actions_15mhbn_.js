module.exports=[87986,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28organic%29_blogs_%5Bslug%5D_page_actions_15mhbn_.js.map