module.exports=[36771,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28organic%29_about-us_page_actions_076c92q.js.map