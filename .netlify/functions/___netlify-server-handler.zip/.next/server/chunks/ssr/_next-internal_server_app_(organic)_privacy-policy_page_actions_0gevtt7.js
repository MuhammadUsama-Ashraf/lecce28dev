module.exports=[67608,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28organic%29_privacy-policy_page_actions_0gevtt7.js.map