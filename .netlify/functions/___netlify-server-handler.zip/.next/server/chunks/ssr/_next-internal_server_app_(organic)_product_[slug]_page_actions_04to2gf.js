module.exports=[70800,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28organic%29_product_%5Bslug%5D_page_actions_04to2gf.js.map