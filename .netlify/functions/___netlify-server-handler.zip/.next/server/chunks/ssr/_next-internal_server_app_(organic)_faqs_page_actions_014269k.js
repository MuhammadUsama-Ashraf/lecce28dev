module.exports=[16173,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28organic%29_faqs_page_actions_014269k.js.map