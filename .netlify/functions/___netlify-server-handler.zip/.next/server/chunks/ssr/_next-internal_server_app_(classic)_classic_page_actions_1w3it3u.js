module.exports=[48045,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28classic%29_classic_page_actions_1w3it3u.js.map