module.exports=[13879,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28organic%29_blogs_page_actions_05wbll8.js.map