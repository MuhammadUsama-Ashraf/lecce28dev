module.exports=[96183,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28organic%29_shop_page_actions_01-emsc.js.map