globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/mSAEn_0rcqfPoNguq8V8F/_buildManifest.js",
    "static/mSAEn_0rcqfPoNguq8V8F/_ssgManifest.js",
    "static/mSAEn_0rcqfPoNguq8V8F/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/3450qyhportkm.js",
    "static/chunks/1j_9b-l0n6u-t.js",
    "static/chunks/3bawhkhjtuhib.js",
    "static/chunks/turbopack-3ncl5o36skv6n.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
